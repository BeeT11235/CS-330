class btTriangle {
	glVec3	apex;
}