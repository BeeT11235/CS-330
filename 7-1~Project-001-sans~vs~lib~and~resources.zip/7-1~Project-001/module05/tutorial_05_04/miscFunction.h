#pragma once
#include <vector>
#include "btTriagnle.h"

using namespace std; // Standard namespace

// basic shap functions
// void createDisk(vector* <btTriagnle>);

void createGMesh00(void);