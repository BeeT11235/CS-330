/*
 * btTriangle.cpp
 *
 *  Created on: Dec 18, 2021
 *      Author: BeeT11235
 *	Triangle object for use with a vcector array and openGL
 */

#pragma once

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

class btTriagnle
{public:
	// three points that make up the triangle
	glm::vec3	apex =			glm::vec3(0.0f, 0.0f, 0.0f);
	glm::vec3	leftPoint =		glm::vec3(0.0f, 0.0f, 0.0f);
	glm::vec3	rightPoint =	glm::vec3(0.0f, 0.0f, 0.0f);

	// RGBA color
	float	red;
	float	green;
	float	blue;
	float	transparent;

	// texture wrap percentages
	float	textureTop = 0.0f;
	float	textureBottom = 0.0f;

	// normal vector for shading
	glm::vec3	normal = glm::vec3(0.0f, 0.0f, 0.0f);

	glm::vec3 calculateNormal(void);
};

