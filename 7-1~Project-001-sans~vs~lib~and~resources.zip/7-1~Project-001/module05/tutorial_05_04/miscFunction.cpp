#include "miscFunction.h"
using namespace std;

void createGMesh00(void) {
	btTriagnle	a;

	a.apex = glm::vec3(-0.5f, -0.5f, 0.0f);
	a.leftPoint = glm::vec3(0.5f, 0.5f, 0.0f);
	a.rightPoint = glm::vec3(-0.5, 0.5, 0.0f);
	vGMesh00.push_back(a);
}
