/*
 * btTriangle.cpp
 *
 *  Created on: Dec 18, 2021
 *      Author: BeeT11235
 *	Triangle object for use with a vcector array and openGL
 */

#include "btTriagnle.h"

btTriagnle::btTriangle() {
	
}

glm::vec3	btTriagnle::calculateNormal() {
	glm::vec3	rightLeg = glm::vec3(0.0f, 0.0f, 0.0f);
	glm::vec3	leftLeg = glm::vec3(0.0f, 0.0f, 0.0f);

	rightLeg = rightPoint - apex;
	leftLeg = leftPoint - apex;

	return	glm::normalize(glm::cross(leftLeg, rightLeg));
}